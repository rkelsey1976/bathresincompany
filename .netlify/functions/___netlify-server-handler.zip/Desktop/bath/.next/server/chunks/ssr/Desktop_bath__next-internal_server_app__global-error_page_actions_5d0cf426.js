module.exports=[65458,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_bath__next-internal_server_app__global-error_page_actions_5d0cf426.js.map