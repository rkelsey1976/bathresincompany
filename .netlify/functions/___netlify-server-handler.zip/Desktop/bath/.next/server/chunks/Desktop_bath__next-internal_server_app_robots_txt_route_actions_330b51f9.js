module.exports=[89592,(e,o,d)=>{}];

//# sourceMappingURL=Desktop_bath__next-internal_server_app_robots_txt_route_actions_330b51f9.js.map