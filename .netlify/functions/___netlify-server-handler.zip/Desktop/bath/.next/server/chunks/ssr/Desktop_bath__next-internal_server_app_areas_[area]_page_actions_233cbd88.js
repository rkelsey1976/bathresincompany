module.exports=[95108,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_bath__next-internal_server_app_areas_%5Barea%5D_page_actions_233cbd88.js.map