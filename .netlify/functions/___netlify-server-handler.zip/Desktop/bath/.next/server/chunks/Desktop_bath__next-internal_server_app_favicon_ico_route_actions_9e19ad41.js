module.exports=[9138,(e,o,d)=>{}];

//# sourceMappingURL=Desktop_bath__next-internal_server_app_favicon_ico_route_actions_9e19ad41.js.map