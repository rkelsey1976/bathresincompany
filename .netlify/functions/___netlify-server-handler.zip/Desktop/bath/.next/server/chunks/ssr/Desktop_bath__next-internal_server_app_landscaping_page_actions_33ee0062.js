module.exports=[27994,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_bath__next-internal_server_app_landscaping_page_actions_33ee0062.js.map