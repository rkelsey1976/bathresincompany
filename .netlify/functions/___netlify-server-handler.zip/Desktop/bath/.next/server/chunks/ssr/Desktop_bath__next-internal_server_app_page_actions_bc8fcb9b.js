module.exports=[14401,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_bath__next-internal_server_app_page_actions_bc8fcb9b.js.map