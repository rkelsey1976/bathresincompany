module.exports=[8767,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},50766,a=>{"use strict";let b={src:a.i(8767).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=Desktop_bath_app_db3493c5._.js.map