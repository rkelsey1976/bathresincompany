module.exports=[72924,(e,o,d)=>{}];

//# sourceMappingURL=Desktop_bath__next-internal_server_app_sitemap_xml_route_actions_099352ed.js.map