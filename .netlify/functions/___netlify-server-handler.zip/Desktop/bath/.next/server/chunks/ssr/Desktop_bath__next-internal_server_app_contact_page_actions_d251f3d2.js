module.exports=[15298,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_bath__next-internal_server_app_contact_page_actions_d251f3d2.js.map