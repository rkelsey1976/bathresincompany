module.exports=[85783,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_bath__next-internal_server_app_about_page_actions_65234205.js.map