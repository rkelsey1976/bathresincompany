module.exports=[95692,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_bath__next-internal_server_app_areas_page_actions_7fa48530.js.map