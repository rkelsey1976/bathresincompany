module.exports=[51302,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_bath__next-internal_server_app__not-found_page_actions_8021e35f.js.map