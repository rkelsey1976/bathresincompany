var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__ca1b8d2e._.js")
R.c("server/chunks/[root-of-the-server]__efcf6604._.js")
R.c("server/chunks/Desktop_bath__next-internal_server_app_sitemap_xml_route_actions_099352ed.js")
R.m(88521)
module.exports=R.m(88521).exports
