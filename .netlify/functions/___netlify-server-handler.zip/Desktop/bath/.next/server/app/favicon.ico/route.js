var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__efcf6604._.js")
R.c("server/chunks/f81c5_next_dist_esm_build_templates_app-route_089dddaf.js")
R.c("server/chunks/Desktop_bath__next-internal_server_app_favicon_ico_route_actions_9e19ad41.js")
R.m(86636)
module.exports=R.m(86636).exports
