var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__8a597854._.js")
R.c("server/chunks/[root-of-the-server]__efcf6604._.js")
R.c("server/chunks/Desktop_bath__next-internal_server_app_robots_txt_route_actions_330b51f9.js")
R.m(6669)
module.exports=R.m(6669).exports
